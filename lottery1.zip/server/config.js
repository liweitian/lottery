/**
 * 奖品设置
 * type: 唯一标识，0是默认特别奖的占位符，其它奖品不可使用
 * count: 奖品数量
 * title: 奖品描述
 * text: 奖品标题
 * img: 图片地址
 */
const prizes = [
  {
    type: 0,
    count: 1000,
    title: "",
    text: "阳光普照"
  },
  {
    type: 1,
    count: 1,
    text: "一等奖",
    title: "IPhone 15 Pro 蓝色钛金属 256G	",
    img: "../img/iphone.jpeg"
  },
  {
    type: 2,
    count: 1,
    text: "二等奖",
    title: "PS5轻薄版+手柄",
    img: "../img/ps5.jpeg"
  },
  {
    type: 3,
    count: 1,
    text: "二等奖",
    title: "Insta 360官方标配",
    img: "../img/insta.jpeg"
  },
  {
    type: 4,
    count: 1,
    text: "二等奖",
    title: "specialized 亮黑色 M 自行车",
    img: "../img/specialize.png"
  },
  {
    type: 5,
    count: 1,
    text: "二等奖",
    title: "Dyson",
    img: "../img/Dyson.png"
  },
  {
    type: 6,
    count: 2,
    text: "二等奖",
    title: "大疆DJI Mini2 SE",
    img: "../img/dji.jpeg"
  },
  {
    type: 7,
    count: 1,
    text: "二等奖",
    title: "哈曼卡顿音箱",
    img: "../img/hamankadun.jpeg"
  },
  {
    type: 8,
    count: 13,
    text: "三等奖",
    title: "茅台飞天、兰蔻菁纯护肤套装等",
    img: "../img/wine.jpg"
  },
  {
    type: 9,
    count: 29,
    text: "四等奖",
    title: "招行金豆*1g、Chanel哑光口红明星组合等",
    img: "../img/gold.jpg"
  },
  {
    type: 10,
    count: 36,
    text: "五等奖",
    title: "diptyque香薰、skg肩颈按摩等",
    img: "/img/diptyque.jpg"
  }
];

/**
 * 一次抽取的奖品个数与prizes对应
 */
const EACH_COUNT = [1, 1, 1, 1, 1, 1, 2, 1, 13, 29, 36];

/**
 * 卡片公司名称标识
 */
const COMPANY = "Construct";

module.exports = {
  prizes,
  EACH_COUNT,
  COMPANY
};
